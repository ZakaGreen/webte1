# Môj TODO List

WEBTE1, zadanie 3 · Ilia Liubotin (xliubotin).
Web: https://webte1.fei.stuba.sk/~xliubotin/Z3_Liubotin/

Aplikácia spravuje úlohy cez školské REST API. Obsahuje formulár, zoznam
s vyhľadávaním, filtrami a zoradením a kalendár s mesiacom, týždňom a dňom.

## Spustenie

Hotová stránka je v koreni archívu. Spustenie cez Python 3:

```sh
python3 -m http.server 8000
```

Otvorte http://localhost:8000/. API potrebuje internet.
Na školský server patria index.html, favicon.svg a priečinok assets/.

Zdrojový projekt je v source/. Potrebujete Node.js 22.12+ a npm:

```sh
cd source
npm install
npm run dev
```

`npm run build` vytvorí priečinok dist/, `npm run preview` spustí náhľad.
Priložený pnpm-lock.yaml uchováva overené verzie pre inštaláciu cez pnpm.

## Technológie a zdroje

Vue 3 a Vite (MIT), Fetch API, HTML a CSS. Kalendár je vlastný,
bez ďalšej knižnice. Favicon je vlastné SVG.
API: https://wt1zadanie.iolab.sk/docs

src/App.vue spravuje spoločné údaje; src/components/ obsahuje formulár,
zoznam a kalendár. src/api.js volá API, src/dates.js spracúva dátumy,
src/style.css obsahuje štýly a src/main.js pripája aplikáciu k HTML.

## Použitie AI

Pri tvorbe projektu boli použité nástroje umelej inteligencie.
